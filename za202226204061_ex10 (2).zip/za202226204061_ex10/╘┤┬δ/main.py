import os
import cv2
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import confusion_matrix, accuracy_score
import matplotlib.pyplot as plt
import seaborn as sns
from glob import glob
from skimage.feature import greycomatrix, greycoprops
from sklearn.cluster import KMeans
from sklearn.svm import SVC
from sklearn.model_selection import GridSearchCV, cross_val_score
from sklearn.feature_selection import RFE

# 设置数据目录路径
train_dir = 'data/train'
test_dir = 'data/test'

# 特征提取方法

# 1. 灰度共生矩阵 (GLCM) 特征
def extract_glcm_features(image_path):
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    glcm = greycomatrix(image, distances=[1], angles=[0], levels=256, symmetric=True, normed=True)
    contrast = greycoprops(glcm, 'contrast')[0, 0]
    dissimilarity = greycoprops(glcm, 'dissimilarity')[0, 0]
    homogeneity = greycoprops(glcm, 'homogeneity')[0, 0]
    energy = greycoprops(glcm, 'energy')[0, 0]
    correlation = greycoprops(glcm, 'correlation')[0, 0]
    return [contrast, dissimilarity, homogeneity, energy, correlation]

# 2. SIFT特征（结合词袋模型）
def extract_sift_features(image_path, kmeans):
    sift = cv2.SIFT_create()
    image = cv2.imread(image_path)
    keypoints, descriptors = sift.detectAndCompute(image, None)
    if descriptors is not None:
        labels = kmeans.predict(descriptors)
        histogram, _ = np.histogram(labels, bins=np.arange(kmeans.n_clusters + 1))
        return histogram
    else:
        return np.zeros(kmeans.n_clusters)

# 3. 颜色直方图特征
def extract_color_histogram(image_path, bins=(8, 8, 8)):
    image = cv2.imread(image_path)
    hist = cv2.calcHist([image], [0, 1, 2], None, bins, [0, 256, 0, 256, 0, 256])
    #归一化
    hist = cv2.normalize(hist, hist).flatten()
    return hist

# 4. 组合所有特征
def extract_combined_features(image_path, kmeans):
    glcm_features = extract_glcm_features(image_path)
    sift_features = extract_sift_features(image_path, kmeans)
    color_histogram = extract_color_histogram(image_path)
    combined_features = np.concatenate([glcm_features, sift_features, color_histogram])
    return combined_features

# 5. 构建词袋模型（Bag of Words）
def build_bow_model(image_paths, n_clusters=50):
    sift = cv2.SIFT_create()
    all_descriptors = []
    for image_path in image_paths:
        image = cv2.imread(image_path)
        keypoints, descriptors = sift.detectAndCompute(image, None)
        if descriptors is not None:
            all_descriptors.append(descriptors)
    all_descriptors = np.vstack(all_descriptors)
    kmeans = KMeans(n_clusters=n_clusters, random_state=0).fit(all_descriptors)
    return kmeans

# 提取数据中的所有图像路径和标签
def load_image_paths_and_labels(data_dir):
    image_paths = []
    labels = []
    for label in sorted(os.listdir(data_dir)):
        class_dir = os.path.join(data_dir, label)
        if os.path.isdir(class_dir):
            for img_path in glob(os.path.join(class_dir, '*.jpg')):
                image_paths.append(img_path)
                labels.append(label)
    return image_paths, labels

# 提取特征向量和标签
def extract_features(image_paths, kmeans):
    features = []
    for image_path in image_paths:
        combined_features = extract_combined_features(image_path, kmeans)
        features.append(combined_features)
    return np.array(features)

# 标准化特征
def standardize_features(X_train, X_test):
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    return X_train_scaled, X_test_scaled

# 递归特征消除
def feature_selection(X_train, y_train, X_test, n_features_to_select=50):
    svm = SVC(kernel='linear')
    rfe = RFE(estimator=svm, n_features_to_select=n_features_to_select, step=1)
    rfe.fit(X_train, y_train)
    print('最佳特征数: {}'.format(rfe.n_features_))
    return rfe.transform(X_train), rfe.transform(X_test)

# 交叉验证寻找最佳参数
def cross_validate_model(X_train, y_train):
    parameters = {
        'kernel': ('linear', 'rbf', 'poly'),
        'C': [0.1, 1, 10, 100],
        'gamma': ['scale', 'auto']
    }
    svc = SVC()
    clf = GridSearchCV(svc, parameters, cv=5)
    clf.fit(X_train, y_train)
    print('最佳参数: {}'.format(clf.best_params_))
    return clf.best_estimator_

# 使用交叉验证评估模型性能
def evaluate_model(model, X, y):
    scores = cross_val_score(model, X, y, cv=5)
    print('交叉验证准确度: {:.2f}%'.format(scores.mean()*100))




# 加载数据
train_image_paths, train_labels = load_image_paths_and_labels(train_dir)
test_image_paths, test_labels = load_image_paths_and_labels(test_dir)

# 构建词袋模型
kmeans = build_bow_model(train_image_paths)

# 提取训练特征和测试特征
X_train = extract_features(train_image_paths, kmeans)
X_test = extract_features(test_image_paths, kmeans)

# 标准化特征
X_train_scaled, X_test_scaled = standardize_features(X_train, X_test)

# 特征选择
X_train_selected, X_test_selected = feature_selection(X_train_scaled, train_labels, X_test_scaled, n_features_to_select=100)

# 交叉验证选择模型
best_model = cross_validate_model(X_train_selected, train_labels)

# 评估模型
evaluate_model(best_model, X_train_selected, train_labels)

# 预测测试集
best_model.fit(X_train_selected, train_labels)
y_pred = best_model.predict(X_test_selected)

# 计算混淆矩阵和准确率
cm = confusion_matrix(test_labels, y_pred)
accuracy = accuracy_score(test_labels, y_pred)

# 绘制混淆矩阵
def plot_confusion_matrix(cm, class_names):
    plt.figure(figsize=(10, 8))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=class_names, yticklabels=class_names)
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.title('Confusion Matrix')
    plt.show()

# 绘制并显示混淆矩阵
label_encoder = LabelEncoder()
label_encoder.fit(train_labels)
plot_confusion_matrix(cm, label_encoder.classes_)

# 输出总体准确率
print('总体准确率: {:.2f}%'.format(accuracy * 100))

# 计算每个类别的准确率
class_accuracies = cm.diagonal() / cm.sum(axis=1)
for i, class_name in enumerate(label_encoder.classes_):
    print('类别 {} 的准确率: {:.2f}%'.format(class_name, class_accuracies[i] * 100))

# 生成分类结果文件
results = []
for idx, (path, true_label, pred_label) in enumerate(zip(test_image_paths, test_labels, y_pred)):
    image_id = int(os.path.basename(path).split('.')[0])
    results.append((image_id, true_label, pred_label))

results = sorted(results, key=lambda x: x[0])

# 保存分类结果
with open('分类结果.txt', 'w') as f:
    for image_id, true_label, pred_label in results:
        f.write('{} {} {}\n'.format(image_id, true_label, pred_label))